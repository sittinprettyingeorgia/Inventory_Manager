module InventoryManagement.MitchellBlake {
    requires javafx.controls;
    requires javafx.fxml;

    opens InventoryManagement;
}